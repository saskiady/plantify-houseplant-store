plantify/
├─ package.json  (you can keep the one from create-react-app)
├─ public/
│  └─ index.html
└─ src/
   ├─ index.js
   ├─ App.js
   ├─ App.css
   ├─ store.js
   ├─ features/
   │  └─ cartSlice.js
   ├─ data/
   │  └─ products.js
   └─ components/
      ├─ Header.js
      ├─ LandingPage.js
      ├─ ProductList.js
      ├─ ProductCard.js
      └─ CartPage.js
